Miniventure
===========

Miniventures is developed by PlayMinicraft and other developers. Our goals are to improve the Minicraft engine to allow more developer to quickly tap into the engine.

Current Team<br>
Shylor (PlayMinicraft)<br>
David (Minicraft+)<br>
Pirate-Rob (Does nothing)
