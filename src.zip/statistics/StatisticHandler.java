package com.mojang.ld22.statistics;

<<<<<<< HEAD
public class StatisticHandler {

=======
/**
 * A class to handle the pushing of statistics
 * @author dillyg10
 *
 */
public class StatisticHandler {
    
    public static final String url = "http://www.playmincraft.com/stats/";

    public void push(ModData mod, Statistic stat){
        //TODO Implementation of this method...
    }
    
    public void pingURL(String data){
        //TODO Figure out if we are going to use a get/post method in order to send statistics
    }
>>>>>>> master
}
