package com.mojang.ld22.statistics.ui;

<<<<<<< HEAD
public class StatisticUI {

=======
import com.mojang.ld22.screen.Menu;

public class StatisticUI extends Menu {
    /*
     * This may become useful for checking current statistics ingame
     * However, not sure if this will be implemented or not...
     * :)- dillyg10
     */
>>>>>>> master
}
