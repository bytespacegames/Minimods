package com.minesaria.minimods;

public class Core {
	public static String getModdedClientVersion() {
		return "v1.0.0";
	}
}
